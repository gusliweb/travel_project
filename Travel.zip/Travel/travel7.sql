-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 07, 2016 at 07:42 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `travel7`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `booking_id` int(10) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `street` varchar(120) NOT NULL,
  `zip_code` int(15) NOT NULL,
  `country` varchar(60) NOT NULL,
  `cusomer_id` int(10) NOT NULL,
  `booking_references` varchar(80) NOT NULL,
  `number_of_booking` int(10) NOT NULL,
  `trip_id` int(10) NOT NULL,
  `Destination_city` varchar(50) NOT NULL,
  `Booking_Description` varchar(250) NOT NULL,
  `Destination_Country` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`booking_id`, `last_name`, `first_name`, `street`, `zip_code`, `country`, `cusomer_id`, `booking_references`, `number_of_booking`, `trip_id`, `Destination_city`, `Booking_Description`, `Destination_Country`) VALUES
(1001, 'ben', 'sam', 'pink street', 15896, 'china', 10001, 'none', 0, 101, 'shanghai', ' china short trip to', 'China'),
(1002, 'pen', 'uam', 'left street', 17496, 'USA', 10002, 'long term', 2, 102, 'lime porte', 'USA trip', 'USA'),
(1003, 'ben', 'sam', 'pink street', 15896, 'china', 10001, 'short trip', 1, 105, 'gothenburg', 'sweden short trip', 'sweden');

-- --------------------------------------------------------

--
-- Table structure for table `booktrip`
--

CREATE TABLE `booktrip` (
  `booking_id` int(11) NOT NULL,
  `cusomer_id` int(11) NOT NULL,
  `trip_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booktrip`
--

INSERT INTO `booktrip` (`booking_id`, `cusomer_id`, `trip_id`) VALUES
(1001, 10001, 101),
(1005, 10002, 105);

-- --------------------------------------------------------

--
-- Table structure for table `cald`
--

CREATE TABLE `cald` (
  `Date` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cald`
--

INSERT INTO `cald` (`Date`) VALUES
(1),
(2),
(3),
(4),
(5),
(6),
(7),
(8),
(9),
(10),
(11),
(12),
(13),
(14),
(15),
(16),
(17),
(18),
(19),
(20),
(21),
(22),
(23),
(24),
(25),
(26),
(27),
(28),
(29),
(30),
(31);

-- --------------------------------------------------------

--
-- Table structure for table `calm`
--

CREATE TABLE `calm` (
  `Month` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `calm`
--

INSERT INTO `calm` (`Month`) VALUES
(1),
(2),
(3),
(4),
(5),
(6),
(7),
(8),
(9),
(10),
(11),
(12);

-- --------------------------------------------------------

--
-- Table structure for table `caly`
--

CREATE TABLE `caly` (
  `Year` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `caly`
--

INSERT INTO `caly` (`Year`) VALUES
(2014),
(2015),
(2016),
(2017);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `cusomer_id` int(10) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `age` int(10) NOT NULL,
  `profession` varchar(20) NOT NULL,
  `telephone` int(15) NOT NULL,
  `street` varchar(120) NOT NULL,
  `zip_code` int(15) NOT NULL,
  `city` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`cusomer_id`, `last_name`, `first_name`, `age`, `profession`, `telephone`, `street`, `zip_code`, `city`) VALUES
(10001, 'ben', 'sam', 28, 'technician', 99874566, 'pink street', 15896, 'shanghai'),
(10002, 'pen', 'uam', 24, 'athlete', 997888, 'left street', 17496, 'new york'),
(10003, 'gtop', 'kolpu', 54, 'medical doctor', 4897, 'loptr beach', 45978, 'Berlin'),
(10004, 'dertn', 'btyum', 34, 'manager', 87958, 'gatan', 876985, 'gothenburg'),
(10005, 'found', 'sim', 40, 'teacher', 3141787, 'isokatu 10', 414141, 'helsinki');

-- --------------------------------------------------------

--
-- Table structure for table `trip`
--

CREATE TABLE `trip` (
  `tripid` int(10) NOT NULL,
  `start_date_of_trip` date NOT NULL,
  `end_date_of_trip` date NOT NULL,
  `destination_city` varchar(50) NOT NULL,
  `country` varchar(60) NOT NULL,
  `count` int(10) NOT NULL,
  `trip_description` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trip`
--

INSERT INTO `trip` (`tripid`, `start_date_of_trip`, `end_date_of_trip`, `destination_city`, `country`, `count`, `trip_description`) VALUES
(101, '2016-07-20', '2016-07-29', 'shanghai', 'china', 1, 'short trip'),
(102, '2016-07-14', '2016-08-18', 'lime porte', 'USA', 2, 'Long trip'),
(103, '2016-07-30', '2016-08-25', 'lime porte', 'UK', 2, 'Mid trip'),
(104, '2016-07-25', '2016-07-27', 'chili', 'Mexico', 1, 'Quick '),
(105, '2016-08-08', '2016-08-15', 'gothenburg', 'sweden', 1, 'short trip'),
(106, '2016-09-05', '2016-09-28', 'hawaii', 'USA', 1, 'Mid trip');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`booking_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`cusomer_id`);

--
-- Indexes for table `trip`
--
ALTER TABLE `trip`
  ADD PRIMARY KEY (`tripid`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
