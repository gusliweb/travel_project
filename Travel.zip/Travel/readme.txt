After unziping of tavel folder  Please follow these simple steps to run this project

1. start xampp server create a new database named 'travel7’
2. import travel7.sql file 
3. start netbeans and select open project option
4. import java files from ’SRC’ folder
5. open travelconnect.java file
6. right click on libraries option and select rs2xml.jar file and mysql-connector-java-   5.1.39-bin.jar file from travel folder.
7. open travelconnect.java file
8. check on line no 20.

Connection conn=DriverManager.getConnection ("jdbc:mysql://localhost/travel7”,”root"," "); //database connection string

		travel7”,”root"," "
	       travel is database name
		root is user name of your mysql by default
		no password required
9. Now build project from run section.
10. lets run our project for application deployment

N.B.- please double click to see the data other wise you will see blank form
